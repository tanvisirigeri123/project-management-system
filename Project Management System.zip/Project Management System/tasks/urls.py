from django.urls import path
from . import views

app_name = 'tasks'

urlpatterns = [
    path('', views.task_list_view, name='task_list'),
    path('my-tasks/', views.my_tasks_view, name='my_tasks'),
    path('<int:pk>/', views.task_detail_view, name='task_detail'),
    path('create/', views.task_create_view, name='task_create'),
    path('<int:pk>/edit/', views.task_update_view, name='task_update'),
    path('<int:pk>/delete/', views.task_delete_view, name='task_delete'),
]
