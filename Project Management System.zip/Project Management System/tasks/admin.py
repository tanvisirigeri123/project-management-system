from django.contrib import admin
from .models import Task, TaskComment, TaskAttachment


@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    list_display = ['title', 'project', 'assigned_to', 'status', 'priority', 'due_date', 'created_at']
    list_filter = ['status', 'priority', 'project', 'due_date']
    search_fields = ['title', 'description', 'project__name', 'assigned_to__username']
    date_hierarchy = 'created_at'
    ordering = ['-created_at']
    
    fieldsets = (
        ('Task Information', {
            'fields': ('title', 'description', 'project', 'assigned_to')
        }),
        ('Task Details', {
            'fields': ('status', 'priority', 'start_date', 'due_date', 'estimated_hours', 'actual_hours')
        }),
        ('Metadata', {
            'fields': ('created_by',),
            'classes': ('collapse',)
        }),
    )


@admin.register(TaskComment)
class TaskCommentAdmin(admin.ModelAdmin):
    list_display = ['task', 'user', 'comment', 'created_at']
    list_filter = ['created_at', 'task']
    search_fields = ['comment', 'user__username', 'task__title']
    date_hierarchy = 'created_at'


@admin.register(TaskAttachment)
class TaskAttachmentAdmin(admin.ModelAdmin):
    list_display = ['task', 'file', 'uploaded_by', 'uploaded_at']
    list_filter = ['uploaded_at']
    search_fields = ['task__title', 'uploaded_by__username']
    date_hierarchy = 'uploaded_at'
