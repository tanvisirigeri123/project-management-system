from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from .models import Task, TaskComment, TaskAttachment
from .forms import TaskForm, TaskCommentForm, TaskAttachmentForm, TaskStatusUpdateForm
from projects.models import Project


@login_required
def task_list_view(request):
    """List all tasks"""
    if request.user.can_manage_projects():
        tasks = Task.objects.all()
    else:
        # Show only tasks assigned to user or in projects they're part of
        tasks = Task.objects.filter(
            Q(assigned_to=request.user) | 
            Q(project__team_members=request.user) |
            Q(project__manager=request.user)
        ).distinct()
    
    # Search functionality
    search_query = request.GET.get('search', '')
    if search_query:
        tasks = tasks.filter(
            Q(title__icontains=search_query) | 
            Q(description__icontains=search_query)
        )
    
    # Filter by status
    status_filter = request.GET.get('status', '')
    if status_filter:
        tasks = tasks.filter(status=status_filter)
    
    # Filter by project
    project_filter = request.GET.get('project', '')
    if project_filter:
        tasks = tasks.filter(project_id=project_filter)
    
    context = {
        'tasks': tasks,
        'search_query': search_query,
        'status_filter': status_filter,
        'project_filter': project_filter,
        'status_choices': Task.STATUS_CHOICES,
        'projects': Project.objects.all() if request.user.can_manage_projects() 
                   else Project.objects.filter(
                       Q(team_members=request.user) | Q(manager=request.user)
                   ).distinct(),
    }
    return render(request, 'tasks/task_list.html', context)


@login_required
def task_detail_view(request, pk):
    """View task details"""
    task = get_object_or_404(Task, pk=pk)
    
    # Check if user has access to this task
    if not request.user.can_manage_projects():
        if (request.user != task.assigned_to and 
            request.user not in task.project.team_members.all() and 
            request.user != task.project.manager):
            messages.error(request, 'You do not have permission to view this task.')
            return redirect('tasks:task_list')
    
    # Handle comment form
    if request.method == 'POST' and 'add_comment' in request.POST:
        comment_form = TaskCommentForm(request.POST)
        if comment_form.is_valid():
            comment = comment_form.save(commit=False)
            comment.task = task
            comment.user = request.user
            comment.save()
            messages.success(request, 'Comment added successfully.')
            return redirect('tasks:task_detail', pk=pk)
    else:
        comment_form = TaskCommentForm()
    
    # Handle attachment form
    if request.method == 'POST' and 'add_attachment' in request.POST:
        attachment_form = TaskAttachmentForm(request.POST, request.FILES)
        if attachment_form.is_valid():
            attachment = attachment_form.save(commit=False)
            attachment.task = task
            attachment.uploaded_by = request.user
            attachment.save()
            messages.success(request, 'Attachment uploaded successfully.')
            return redirect('tasks:task_detail', pk=pk)
    else:
        attachment_form = TaskAttachmentForm()
    
    # Handle status update
    if request.method == 'POST' and 'update_status' in request.POST:
        status_form = TaskStatusUpdateForm(request.POST, instance=task)
        if status_form.is_valid():
            status_form.save()
            messages.success(request, 'Task status updated successfully.')
            return redirect('tasks:task_detail', pk=pk)
    else:
        status_form = TaskStatusUpdateForm(instance=task)
    
    context = {
        'task': task,
        'comment_form': comment_form,
        'attachment_form': attachment_form,
        'status_form': status_form,
        'comments': task.comments.all(),
        'attachments': task.attachments.all(),
    }
    return render(request, 'tasks/task_detail.html', context)


@login_required
def task_create_view(request):
    """Create a new task"""
    if not request.user.can_assign_tasks():
        messages.error(request, 'You do not have permission to create tasks.')
        return redirect('tasks:task_list')
    
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            task = form.save(commit=False)
            task.created_by = request.user
            task.save()
            messages.success(request, f'Task "{task.title}" created successfully.')
            return redirect('tasks:task_detail', pk=task.pk)
    else:
        # Pre-select project if provided in URL
        project_id = request.GET.get('project')
        initial = {}
        if project_id:
            initial['project'] = project_id
        form = TaskForm(initial=initial)
    
    context = {'form': form, 'title': 'Create New Task'}
    return render(request, 'tasks/task_form.html', context)


@login_required
def task_update_view(request, pk):
    """Update an existing task"""
    task = get_object_or_404(Task, pk=pk)
    
    if not request.user.can_assign_tasks():
        messages.error(request, 'You do not have permission to edit tasks.')
        return redirect('tasks:task_detail', pk=pk)
    
    if request.method == 'POST':
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            messages.success(request, f'Task "{task.title}" updated successfully.')
            return redirect('tasks:task_detail', pk=task.pk)
    else:
        form = TaskForm(instance=task)
    
    context = {'form': form, 'task': task, 'title': 'Edit Task'}
    return render(request, 'tasks/task_form.html', context)


@login_required
def task_delete_view(request, pk):
    """Delete a task"""
    task = get_object_or_404(Task, pk=pk)
    
    if not request.user.can_assign_tasks():
        messages.error(request, 'You do not have permission to delete tasks.')
        return redirect('tasks:task_detail', pk=pk)
    
    if request.method == 'POST':
        task_title = task.title
        task.delete()
        messages.success(request, f'Task "{task_title}" deleted successfully.')
        return redirect('tasks:task_list')
    
    context = {'task': task}
    return render(request, 'tasks/task_confirm_delete.html', context)


@login_required
def my_tasks_view(request):
    """View tasks assigned to current user"""
    tasks = Task.objects.filter(assigned_to=request.user)
    
    # Filter by status
    status_filter = request.GET.get('status', '')
    if status_filter:
        tasks = tasks.filter(status=status_filter)
    
    context = {
        'tasks': tasks,
        'status_filter': status_filter,
        'status_choices': Task.STATUS_CHOICES,
    }
    return render(request, 'tasks/my_tasks.html', context)
