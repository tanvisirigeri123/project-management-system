from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Q
from django.utils import timezone
from projects.models import Project
from tasks.models import Task


def home_view(request):
    """Home page view"""
    if request.user.is_authenticated:
        return redirect('dashboard')
    return render(request, 'home.html')


@login_required
def dashboard_view(request):
    """Main dashboard view"""
    user = request.user
    
    # Get user's projects
    if user.can_manage_projects():
        projects = Project.objects.all()[:5]
        total_projects = Project.objects.count()
    else:
        projects = Project.objects.filter(
            Q(team_members=user) | Q(manager=user)
        ).distinct()[:5]
        total_projects = Project.objects.filter(
            Q(team_members=user) | Q(manager=user)
        ).distinct().count()
    
    # Get tasks based on user role
    if user.can_manage_projects():
        # Admin/Manager can see all tasks
        all_tasks = Task.objects.all()
        my_tasks = Task.objects.filter(assigned_to=user)
    else:
        # Regular users see only their assigned tasks
        all_tasks = Task.objects.filter(assigned_to=user)
        my_tasks = all_tasks
    
    # Stats for the user's own tasks
    pending_tasks = my_tasks.exclude(status='completed').count()
    completed_tasks = my_tasks.filter(status='completed').count()
    overdue_tasks = my_tasks.filter(
        due_date__lt=timezone.now().date(),
        status__in=['todo', 'in_progress', 'in_review']
    ).count()
    
    # Recent tasks
    recent_tasks = my_tasks[:10]
    
    # Task status breakdown (for ALL tasks if admin, otherwise user's tasks)
    task_status_counts = {
        'todo': all_tasks.filter(status='todo').count(),
        'in_progress': all_tasks.filter(status='in_progress').count(),
        'in_review': all_tasks.filter(status='in_review').count(),
        'completed': all_tasks.filter(status='completed').count(),
        'blocked': all_tasks.filter(status='blocked').count(),
    }
    
    # Total tasks for percentage calculation
    total_tasks_count = all_tasks.count()
    total_completed = all_tasks.filter(status='completed').count()
    total_pending = total_tasks_count - total_completed
    
    context = {
        'projects': projects,
        'total_projects': total_projects,
        'my_tasks': recent_tasks,
        'pending_tasks': pending_tasks,
        'completed_tasks': completed_tasks,
        'overdue_tasks': overdue_tasks,
        'task_status_counts': task_status_counts,
        'total_tasks_count': total_tasks_count,
        'total_completed': total_completed,
        'total_pending': total_pending,
    }
    return render(request, 'dashboard.html', context)

