# Quick Setup Guide

This file contains quick commands to get started with the Project Management System.

## First Time Setup

1. Create a superuser (Admin):
```
python manage.py createsuperuser
```

Enter username, email, and password when prompted.

2. Run the development server:
```
python manage.py runserver
```

3. Access the application:
- Home: http://127.0.0.1:8000/
- Login: http://127.0.0.1:8000/accounts/login/
- Admin: http://127.0.0.1:8000/admin/

## Creating Test Data

You can create test users through the admin panel or by registering through the web interface.

### Recommended Test Users

Create these users for testing different roles:

1. Admin User (via createsuperuser)
   - Username: admin
   - Role: Admin (set in admin panel)

2. Manager User (via registration)
   - Username: manager
   - Role: Manager
   - Can create projects and assign tasks

3. Developer User (via registration)
   - Username: developer
   - Role: Developer
   - Can work on assigned tasks

4. Tester User (via registration)
   - Username: tester
   - Role: Tester
   - Can test and update task status

## Quick Commands

### Database
```
# Make migrations
python manage.py makemigrations

# Apply migrations
python manage.py migrate

# Reset database (WARNING: deletes all data)
del db.sqlite3
python manage.py migrate
python manage.py createsuperuser
```

### Static Files
```
# Collect static files (for production)
python manage.py collectstatic
```

### Development
```
# Run development server
python manage.py runserver

# Run on different port
python manage.py runserver 8080

# Run on all network interfaces
python manage.py runserver 0.0.0.0:8000
```

## Default Login Flow

1. Register a new account at /accounts/register/
2. Select your role (Admin, Manager, Developer, or Tester)
3. Login with your credentials
4. You'll be redirected to your dashboard

## Testing the System

1. Login as Admin/Manager
2. Create a new project
3. Add team members to the project
4. Create tasks and assign them to team members
5. Login as Developer/Tester
6. View and update assigned tasks
7. Login as Admin/Manager again
8. View reports and generate PDFs

## Troubleshooting

If you encounter any issues:

1. Make sure all dependencies are installed:
```
pip install -r requirements.txt
```

2. Ensure migrations are applied:
```
python manage.py migrate
```

3. Check if the development server is running:
```
python manage.py runserver
```

4. Clear browser cache if styles are not loading

5. Check console for any error messages
