# Getting Started with Project Management System

## 🚀 5-Minute Quick Start Guide

Follow these simple steps to get your Project Management System up and running!

---

## Step 1: Open Terminal/Command Prompt

Navigate to your project directory:
```bash
cd "c:\Users\preet\OneDrive\Desktop\Project Management System"
```

---

## Step 2: Create Your Admin Account

Run this command to create a superuser:
```bash
python manage.py createsuperuser
```

You'll be asked to provide:
- **Username**: Your admin username (e.g., "admin")
- **Email**: Your email address (optional, press Enter to skip)
- **Password**: Your password (you'll type it twice)

**Note**: The password won't show as you type - this is normal!

---

## Step 3: (Optional) Load Sample Data

Want to test the system with pre-made data? Run:
```bash
python manage.py shell < create_sample_data.py
```

This creates:
- 4 test users (manager, 2 developers, 1 tester)
- 3 projects with various statuses
- 10 tasks with different assignments

**Test Login Credentials:**
- Manager: `john_manager` / `test1234`
- Developer: `alice_dev` / `test1234`
- Developer: `bob_dev` / `test1234`
- Tester: `charlie_tester` / `test1234`

---

## Step 4: Start the Server

Run the development server:
```bash
python manage.py runserver
```

You should see:
```
Starting development server at http://127.0.0.1:8000/
```

---

## Step 5: Open Your Browser

Visit: **http://127.0.0.1:8000/**

You'll see the beautiful home page!

---

## Step 6: Login and Explore

### Option A: Login with Admin Account
1. Click "Login" button
2. Enter your superuser credentials
3. You'll be redirected to the dashboard

### Option B: Register a New Account
1. Click "Register" button
2. Fill in your details
3. Select your role (Admin, Manager, Developer, or Tester)
4. Submit and you'll be auto-logged in

---

## 📱 What You Can Do Now

### As Admin or Manager:
1. **Create a Project**
   - Click "Projects" → "Create New Project"
   - Fill in project details
   - Assign team members
   - Click "Save Project"

2. **Create Tasks**
   - Click "Tasks" → "Create New Task"
   - Select a project
   - Assign to a team member
   - Set due date and priority
   - Click "Save Task"

3. **View Reports**
   - Click "Reports" in navigation
   - See overall statistics
   - Click on any project to see detailed report
   - Download PDF reports

### As Developer or Tester:
1. **View Your Tasks**
   - Click "My Tasks" in navigation
   - See all tasks assigned to you
   - Click on any task to view details

2. **Update Task Status**
   - Open a task
   - Use the status form to update
   - Add comments or attachments

3. **View Your Profile**
   - Click on your username → "Profile"
   - Update your information
   - Upload a profile picture

---

## 🎯 Common Tasks

### Create Your First Project
1. Login as Admin or Manager
2. Click "Projects" → "Create New Project"
3. Fill in:
   - Project Name (e.g., "Website Redesign")
   - Description
   - Select Status: "Planning"
   - Select Priority: "High"
   - Set Start Date and End Date
   - Choose yourself as Manager
   - Add team members
4. Click "Save Project"

### Assign Your First Task
1. Go to "Tasks" → "Create New Task"
2. Fill in:
   - Task Title (e.g., "Design Homepage")
   - Description
   - Select the project you just created
   - Assign to a team member
   - Set Status: "To Do"
   - Set Priority: "High"
   - Set Due Date
3. Click "Save Task"

### View Progress
1. Go to your Dashboard
2. See project statistics
3. View task completion status
4. Check overdue tasks

### Generate a Report
1. Click "Reports" in navigation
2. Click on a project name
3. View detailed statistics
4. Click "Download PDF" to save report

---

## ⚡ Pro Tips

### Use the Quick Start Script (Windows)
Double-click `quickstart.bat` for a menu of common commands!

### Keyboard Shortcuts
- `Ctrl + C` in terminal to stop the server
- Use browser back button to navigate back

### Navigation Tips
- Dashboard shows your overview
- "My Tasks" shows only your assignments
- Use search bars to find specific items
- Filter by status to organize views

### Managing Users
1. Go to http://127.0.0.1:8000/admin/
2. Login with your superuser account
3. You can:
   - View all users
   - Change user roles
   - Activate/deactivate users
   - Manage all data

---

## 🔧 Troubleshooting

### "Command not found" Error
Make sure Python is installed and in your PATH.

### "Port already in use" Error
Another application is using port 8000. Try:
```bash
python manage.py runserver 8080
```
Then visit: http://127.0.0.1:8080/

### Static Files Not Loading
Run:
```bash
python manage.py collectstatic
```

### Database Issues
Reset the database:
```bash
del db.sqlite3
python manage.py migrate
python manage.py createsuperuser
```

---

## 📚 Next Steps

1. **Explore the Features**
   - Create multiple projects
   - Assign tasks to different users
   - Add comments and attachments
   - Generate reports

2. **Read the Documentation**
   - Check `README.md` for detailed info
   - Review `PROJECT_SUMMARY.md` for technical details
   - See `CHECKLIST.md` for all features

3. **Customize**
   - Modify `static/css/custom.css` for styling
   - Add your company logo
   - Customize email settings
   - Add more features

---

## 🎉 You're All Set!

Your Project Management System is now running and ready to use!

**Questions?** Check the README.md file for comprehensive documentation.

**Issues?** Review the Troubleshooting section above.

**Enjoy managing your projects efficiently!** 🚀

---

**Remember**: 
- Press `Ctrl + C` in terminal to stop the server
- Don't close the terminal while using the application
- Server must be running to access the web interface

**Happy Project Managing!** 😊
