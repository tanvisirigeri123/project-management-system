# Quick Reference Guide - UI Features

## 🎨 Visual Elements Reference

### Gradient Color Classes

Use these CSS variables in your custom styles:

```css
/* Background Gradients */
background: var(--primary-gradient);   /* Purple gradient */
background: var(--success-gradient);   /* Green gradient */
background: var(--warning-gradient);   /* Pink gradient */
background: var(--info-gradient);      /* Blue gradient */
```

### CSS Classes

#### Cards
- `.glass-card` - Frosted glass effect
- `.project-card` - Enhanced project card with hover effects
- `.task-card` - Enhanced task card with status styling
- `.stat-card` - Statistic card with hover animation

#### Text & Typography
- `.text-gradient` - Gradient text effect for headings
- `.fw-bold` - Bold font weight
- `.small` - Smaller text size

#### Animations
- `.floating` - Floating animation for icons
- `.project-status-indicator` - Pulse animation circle
- `.priority-critical` - Critical pulse animation
- `.dashboard-icon` - Positioned icon for cards

#### Badges
- Use inline styles with gradient variables for status badges
- `.badge` with gradient backgrounds for modern look

#### Progress Bars
- Standard Bootstrap `.progress` with gradient backgrounds
- Animated with pulse effects automatically

---

## 🎯 Page-Specific Features

### Home Page
- **Hero Section**: Animated gradient background
- **Floating Icon**: Kanban icon with bounce animation
- **Features**: Glass-card boxes with gradient icons
- **Roles**: Gradient background showcase cards

### Dashboard
- **Stats Cards**: Large gradient cards with positioned icons
- **Recent Items**: Enhanced lists with gradient headers
- **Status Overview**: Color-coded boxes with border accents
- **Quick Actions**: Gradient panel with centered buttons

### Projects List
- **Search Panel**: Glass-card with icon-prefixed inputs
- **Project Cards**: Team avatars, status pulse, gradient progress
- **Empty State**: Illustrated no-data state

### Tasks List
- **Filter Layout**: Three-column search, status, project
- **Task Cards**: Priority badges, overdue warnings
- **Metadata**: Icon-prefixed information

### My Tasks
- **Personal View**: Days remaining countdown
- **Card Footer**: Quick status with emojis
- **Time Display**: Estimated hours shown

### Reports Dashboard
- **Large Stats**: Display-sized numbers with icons
- **Data Table**: Enhanced with gradients and progress
- **Distribution**: Visual status breakdown with bars

---

## 🎨 Design Tokens Quick Reference

### Colors
```
Primary:   #667eea → #764ba2 (Purple)
Success:   #11998e → #38ef7d (Green)
Warning:   #f093fb → #f5576c (Pink)
Info:      #4facfe → #00f2fe (Blue)
```

### Spacing
```
xs:  4px   (0.25rem)
sm:  8px   (0.5rem)
md:  16px  (1rem)
lg:  24px  (1.5rem)
xl:  32px  (2rem)
xxl: 48px  (3rem)
```

### Border Radius
```
Small:  4px  - Badges
Medium: 8px  - Buttons
Large:  12px - Cards
XLarge: 16px - Modals
```

### Shadows
```
sm: 0 2px 4px rgba(0,0,0,0.1)
md: 0 4px 6px rgba(0,0,0,0.1)
lg: 0 10px 15px rgba(0,0,0,0.1)
xl: 0 20px 25px rgba(0,0,0,0.15)
```

---

## 🚀 Animation Classes

### Available Animations

**@keyframes gradientShift**
- Duration: 15s
- Effect: Smooth background gradient transition
- Usage: Applied to `.animated-gradient`

**@keyframes float**
- Duration: 3s
- Effect: Vertical bounce movement
- Usage: Applied to `.floating`

**@keyframes criticalPulse**
- Duration: 2s
- Effect: Scale and opacity pulse
- Usage: Applied to `.priority-critical`

**@keyframes pulse**
- Duration: 2s
- Effect: Opacity pulse
- Usage: Applied to `.project-status-indicator`

**@keyframes slideInDown**
- Duration: 0.5s
- Effect: Slide from top with fade
- Usage: Applied to `.alert`

**@keyframes fadeIn**
- Duration: 0.5s
- Effect: Fade in opacity
- Usage: Applied to various elements

**@keyframes sparkle**
- Duration: 1.5s
- Effect: Shine effect
- Usage: Applied to success elements

---

## 📝 HTML Structure Patterns

### Glass Card Template
```html
<div class="card border-0 shadow-lg glass-card">
    <div class="card-header text-white" style="background: var(--primary-gradient);">
        <h5 class="mb-0"><i class="bi bi-icon"></i> Title</h5>
    </div>
    <div class="card-body">
        <!-- Content -->
    </div>
</div>
```

### Gradient Stat Card
```html
<div class="card border-0 shadow-lg text-white h-100" style="background: var(--primary-gradient);">
    <div class="card-body text-center position-relative">
        <i class="bi bi-folder dashboard-icon"></i>
        <h2 class="display-4 fw-bold mb-2">42</h2>
        <p class="mb-2 fw-bold">Label</p>
        <small class="d-block opacity-75">Details</small>
    </div>
</div>
```

### Status Badge
```html
<span class="badge" style="background: var(--success-gradient);">
    Completed
</span>
```

### Progress Bar
```html
<div class="progress" style="height: 10px;">
    <div class="progress-bar" role="progressbar" 
         style="width: 75%; background: var(--primary-gradient);"></div>
</div>
```

### Team Avatars
```html
<div class="d-flex align-items-center">
    {% for member in team_members|slice:":3" %}
    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center" 
         style="width: 30px; height: 30px; margin-left: -8px; border: 2px solid white; font-size: 0.75rem;">
        {{ member.get_full_name|slice:":1"|upper }}
    </div>
    {% endfor %}
</div>
```

### Status Indicator
```html
<span class="project-status-indicator me-2" 
      style="background: {% if status == 'completed' %}#28a745{% elif status == 'in_progress' %}#0d6efd{% else %}#ffc107{% endif %};"></span>
```

---

## 🎯 Common Patterns

### Icon-Prefixed Input
```html
<div class="input-group">
    <span class="input-group-text border-0 bg-light">
        <i class="bi bi-search"></i>
    </span>
    <input type="text" class="form-control border-0 shadow-sm" placeholder="Search...">
</div>
```

### Gradient Header
```html
<h2 class="text-gradient fw-bold mb-0">
    <i class="bi bi-icon floating"></i> Page Title
</h2>
<p class="text-muted mb-0">Subtitle description</p>
```

### Empty State
```html
<div class="card border-0 shadow-lg glass-card text-center py-5">
    <div class="card-body">
        <i class="bi bi-icon" style="font-size: 5rem; color: #ddd;"></i>
        <h4 class="mt-4 mb-3">No Items Found</h4>
        <p class="text-muted mb-4">Description text</p>
        <a href="#" class="btn btn-primary">Call to Action</a>
    </div>
</div>
```

---

## 📱 Responsive Classes

### Bootstrap Grid
```html
<!-- Desktop: 2 columns, Tablet: 1 column, Mobile: 1 column -->
<div class="col-lg-6 col-12 mb-4">
    <!-- Content -->
</div>

<!-- Desktop: 4 columns, Tablet: 2 columns, Mobile: 1 column -->
<div class="col-lg-3 col-md-6 col-12 mb-3">
    <!-- Content -->
</div>
```

### Responsive Utilities
- `d-none d-md-block` - Hide on mobile, show on tablet+
- `d-md-none` - Show on mobile, hide on tablet+
- `text-center text-md-start` - Center on mobile, left-align on tablet+

---

## 🎨 Emoji Reference

Use these emojis in your HTML for enhanced visual appeal:

### Status Emojis
- ✅ Completed
- 🚀 In Progress
- 🔍 In Review/Testing
- 🚫 Blocked
- 📝 To Do/Planning

### Action Emojis
- 📁 Folder/Project
- 📋 List/Tasks
- 👤 Person/User
- 👥 Team/Group
- 📅 Calendar/Date
- ⏱️ Time/Duration
- 🚩 Priority/Flag
- 📊 Chart/Reports
- ⚠️ Warning/Alert
- 🔥 Urgent/Hot

---

## 🔧 Customization Tips

### Change Primary Gradient
```css
:root {
    --primary-gradient: linear-gradient(135deg, YOUR_COLOR1, YOUR_COLOR2);
}
```

### Adjust Animation Speed
```css
.floating {
    animation: float 5s ease-in-out infinite; /* Change 3s to 5s */
}
```

### Modify Glass Effect Blur
```css
.glass-card {
    backdrop-filter: blur(15px); /* Change 10px to 15px */
}
```

### Add New Gradient
```css
:root {
    --custom-gradient: linear-gradient(135deg, #color1 0%, #color2 100%);
}

/* Use it */
.my-element {
    background: var(--custom-gradient);
}
```

---

## 🎯 Best Practices

### Do's ✅
- Use gradient variables for consistency
- Apply glass-card class for modern look
- Add floating class to hero icons
- Use status indicators for projects/tasks
- Include team avatars where applicable
- Add empty states for better UX
- Use icon-prefixed inputs
- Apply responsive classes

### Don'ts ❌
- Don't hardcode gradient colors
- Don't skip empty states
- Don't forget mobile responsiveness
- Don't overuse animations
- Don't ignore accessibility
- Don't mix different design patterns

---

## 📚 Additional Resources

### Documentation Files
- `UI_UX_ENHANCEMENTS.md` - Complete design documentation
- `VISUAL_SHOWCASE.md` - Visual examples and layouts
- `CHANGELOG.md` - Version history and changes

### External Resources
- Bootstrap Icons: https://icons.getbootstrap.com/
- Bootstrap Docs: https://getbootstrap.com/docs/5.3/
- CSS Gradients: https://cssgradient.io/
- Color Picker: https://colorhunt.co/

---

## 🎉 Quick Start Checklist

When creating a new page:

1. [ ] Use glass-card for main containers
2. [ ] Add text-gradient to page titles
3. [ ] Include floating animation on hero icons
4. [ ] Apply gradient backgrounds to stat cards
5. [ ] Use status indicators where applicable
6. [ ] Add team avatars for collaborative features
7. [ ] Include empty states
8. [ ] Apply responsive classes
9. [ ] Test on mobile, tablet, and desktop
10. [ ] Check color contrast for accessibility

---

*For detailed implementation, refer to the main documentation files.*
*Last Updated: 2024*
