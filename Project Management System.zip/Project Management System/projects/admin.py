from django.contrib import admin
from .models import Project, ProjectComment


@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ['name', 'manager', 'status', 'priority', 'start_date', 'end_date', 'created_at']
    list_filter = ['status', 'priority', 'start_date', 'end_date']
    search_fields = ['name', 'description', 'manager__username']
    filter_horizontal = ['team_members']
    date_hierarchy = 'created_at'
    ordering = ['-created_at']
    
    fieldsets = (
        ('Project Information', {
            'fields': ('name', 'description', 'manager', 'team_members')
        }),
        ('Project Details', {
            'fields': ('status', 'priority', 'start_date', 'end_date', 'budget')
        }),
        ('Metadata', {
            'fields': ('created_by',),
            'classes': ('collapse',)
        }),
    )


@admin.register(ProjectComment)
class ProjectCommentAdmin(admin.ModelAdmin):
    list_display = ['project', 'user', 'comment', 'created_at']
    list_filter = ['created_at', 'project']
    search_fields = ['comment', 'user__username', 'project__name']
    date_hierarchy = 'created_at'
