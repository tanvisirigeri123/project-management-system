from django.urls import path
from . import views

app_name = 'projects'

urlpatterns = [
    path('', views.project_list_view, name='project_list'),
    path('<int:pk>/', views.project_detail_view, name='project_detail'),
    path('create/', views.project_create_view, name='project_create'),
    path('<int:pk>/edit/', views.project_update_view, name='project_update'),
    path('<int:pk>/delete/', views.project_delete_view, name='project_delete'),
]
