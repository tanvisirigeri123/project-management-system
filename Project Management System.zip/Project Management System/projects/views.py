from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q, Count
from .models import Project, ProjectComment
from .forms import ProjectForm, ProjectCommentForm


@login_required
def project_list_view(request):
    """List all projects"""
    if request.user.can_manage_projects():
        projects = Project.objects.all()
    else:
        # Show only projects where user is a team member or manager
        projects = Project.objects.filter(
            Q(team_members=request.user) | Q(manager=request.user)
        ).distinct()
    
    # Search functionality
    search_query = request.GET.get('search', '')
    if search_query:
        projects = projects.filter(
            Q(name__icontains=search_query) | 
            Q(description__icontains=search_query)
        )
    
    # Filter by status
    status_filter = request.GET.get('status', '')
    if status_filter:
        projects = projects.filter(status=status_filter)
    
    # Annotate with task count
    projects = projects.annotate(task_count=Count('tasks'))
    
    context = {
        'projects': projects,
        'search_query': search_query,
        'status_filter': status_filter,
        'status_choices': Project.STATUS_CHOICES,
    }
    return render(request, 'projects/project_list.html', context)


@login_required
def project_detail_view(request, pk):
    """View project details"""
    project = get_object_or_404(Project, pk=pk)
    
    # Check if user has access to this project
    if not request.user.can_manage_projects():
        if request.user not in project.team_members.all() and request.user != project.manager:
            messages.error(request, 'You do not have permission to view this project.')
            return redirect('projects:project_list')
    
    # Handle comment form
    if request.method == 'POST':
        comment_form = ProjectCommentForm(request.POST)
        if comment_form.is_valid():
            comment = comment_form.save(commit=False)
            comment.project = project
            comment.user = request.user
            comment.save()
            messages.success(request, 'Comment added successfully.')
            return redirect('projects:project_detail', pk=pk)
    else:
        comment_form = ProjectCommentForm()
    
    context = {
        'project': project,
        'comment_form': comment_form,
        'tasks': project.tasks.all()[:10],  # Latest 10 tasks
        'comments': project.comments.all()[:10],  # Latest 10 comments
    }
    return render(request, 'projects/project_detail.html', context)


@login_required
def project_create_view(request):
    """Create a new project"""
    if not request.user.can_manage_projects():
        messages.error(request, 'You do not have permission to create projects.')
        return redirect('projects:project_list')
    
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():
            project = form.save(commit=False)
            project.created_by = request.user
            project.save()
            form.save_m2m()  # Save many-to-many relationships
            messages.success(request, f'Project "{project.name}" created successfully.')
            return redirect('projects:project_detail', pk=project.pk)
    else:
        form = ProjectForm()
    
    context = {'form': form, 'title': 'Create New Project'}
    return render(request, 'projects/project_form.html', context)


@login_required
def project_update_view(request, pk):
    """Update an existing project"""
    project = get_object_or_404(Project, pk=pk)
    
    if not request.user.can_manage_projects():
        messages.error(request, 'You do not have permission to edit projects.')
        return redirect('projects:project_detail', pk=pk)
    
    if request.method == 'POST':
        form = ProjectForm(request.POST, instance=project)
        if form.is_valid():
            form.save()
            messages.success(request, f'Project "{project.name}" updated successfully.')
            return redirect('projects:project_detail', pk=project.pk)
    else:
        form = ProjectForm(instance=project)
    
    context = {'form': form, 'project': project, 'title': 'Edit Project'}
    return render(request, 'projects/project_form.html', context)


@login_required
def project_delete_view(request, pk):
    """Delete a project"""
    project = get_object_or_404(Project, pk=pk)
    
    if not request.user.can_manage_projects():
        messages.error(request, 'You do not have permission to delete projects.')
        return redirect('projects:project_detail', pk=pk)
    
    if request.method == 'POST':
        project_name = project.name
        project.delete()
        messages.success(request, f'Project "{project_name}" deleted successfully.')
        return redirect('projects:project_list')
    
    context = {'project': project}
    return render(request, 'projects/project_confirm_delete.html', context)
