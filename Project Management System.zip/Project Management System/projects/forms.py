from django import forms
from .models import Project, ProjectComment
from accounts.models import User


class ProjectForm(forms.ModelForm):
    """Form for creating and updating projects"""
    
    team_members = forms.ModelMultipleChoiceField(
        queryset=User.objects.all(),
        widget=forms.CheckboxSelectMultiple,
        required=False
    )
    
    class Meta:
        model = Project
        fields = ['name', 'description', 'status', 'priority', 'start_date', 
                  'end_date', 'budget', 'manager', 'team_members']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 4}),
            'status': forms.Select(attrs={'class': 'form-control'}),
            'priority': forms.Select(attrs={'class': 'form-control'}),
            'start_date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'end_date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'budget': forms.NumberInput(attrs={'class': 'form-control'}),
            'manager': forms.Select(attrs={'class': 'form-control'}),
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Filter managers to only show admin and manager roles
        self.fields['manager'].queryset = User.objects.filter(role__in=['admin', 'manager'])


class ProjectCommentForm(forms.ModelForm):
    """Form for adding comments to projects"""
    
    class Meta:
        model = ProjectComment
        fields = ['comment']
        widgets = {
            'comment': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Add a comment...'
            }),
        }
