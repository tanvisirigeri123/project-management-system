from django.db import models
from django.conf import settings
from django.utils import timezone


class Project(models.Model):
    """Project model for managing projects"""
    
    STATUS_CHOICES = [
        ('planning', 'Planning'),
        ('in_progress', 'In Progress'),
        ('testing', 'Testing'),
        ('completed', 'Completed'),
        ('on_hold', 'On Hold'),
    ]
    
    PRIORITY_CHOICES = [
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('critical', 'Critical'),
    ]
    
    name = models.CharField(max_length=200)
    description = models.TextField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='planning')
    priority = models.CharField(max_length=20, choices=PRIORITY_CHOICES, default='medium')
    start_date = models.DateField()
    end_date = models.DateField()
    budget = models.DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    manager = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.CASCADE, 
        related_name='managed_projects',
        limit_choices_to={'role__in': ['admin', 'manager']}
    )
    team_members = models.ManyToManyField(
        settings.AUTH_USER_MODEL, 
        related_name='projects', 
        blank=True
    )
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        related_name='created_projects'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.name
    
    def get_progress(self):
        """Calculate project progress based on tasks"""
        tasks = self.tasks.all()
        if not tasks:
            return 0
        completed_tasks = tasks.filter(status='completed').count()
        return round((completed_tasks / tasks.count()) * 100, 2)
    
    def get_task_count(self):
        """Get total task count"""
        return self.tasks.count()
    
    def get_completed_tasks(self):
        """Get completed task count"""
        return self.tasks.filter(status='completed').count()
    
    def is_overdue(self):
        """Check if project is overdue"""
        return timezone.now().date() > self.end_date and self.status != 'completed'
    
    def days_remaining(self):
        """Calculate days remaining"""
        if self.status == 'completed':
            return 0
        delta = self.end_date - timezone.now().date()
        return max(0, delta.days)
    
    class Meta:
        ordering = ['-created_at']
        permissions = [
            ('can_manage_all_projects', 'Can manage all projects'),
        ]


class ProjectComment(models.Model):
    """Comments for projects"""
    
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='comments')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    comment = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Comment by {self.user.username} on {self.project.name}"
    
    class Meta:
        ordering = ['-created_at']
