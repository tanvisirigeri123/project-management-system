# Project Management System (PMS)

A comprehensive web-based Project Management System built with Django featuring a **modern, unique UI** with gradient designs, glass morphism effects, and smooth animations. Manage projects, tasks, and team members efficiently with role-based access control.

## ✨ What's New in Version 2.0

### 🎨 Complete UI/UX Overhaul
- **Modern Gradient Design**: Beautiful color gradients throughout the interface
- **Glass Morphism Effects**: Frosted glass cards for a contemporary look
- **Smooth Animations**: Floating icons, pulse effects, and animated progress bars
- **Enhanced Visual Hierarchy**: Improved typography with gradient text effects
- **Status Indicators**: Animated pulse indicators for projects and tasks
- **Responsive Design**: Optimized for all screen sizes (mobile, tablet, desktop)

> See [UI_UX_ENHANCEMENTS.md](docs/UI_UX_ENHANCEMENTS.md) for complete design documentation

## Features

### Core Features
- **User Management with Role-Based Access Control**
  - Admin: Full system access
  - Manager: Project and task management, reports access
  - Developer: Task execution and status updates
  - Tester: Task testing and feedback

- **Project Management**
  - Create, Read, Update, Delete (CRUD) operations
  - Project status tracking (Planning, In Progress, Testing, Completed, On Hold)
  - Priority levels (Low, Medium, High, Critical)
  - Team member assignment with avatar display
  - Project progress calculation based on tasks
  - Budget tracking
  - Project comments
  - **NEW**: Visual progress bars with gradient fills
  - **NEW**: Team member avatar circles
  - **NEW**: Status pulse indicators

- **Task Management**
  - Complete CRUD operations for tasks
  - Task assignment to team members
  - Status tracking (To Do, In Progress, In Review, Completed, Blocked)
  - Priority levels with gradient badges
  - Due date tracking with overdue detection
  - Task comments and discussions
  - File attachments
  - Estimated vs actual hours tracking
  - **NEW**: Days remaining countdown
  - **NEW**: Critical pulse animations for urgent tasks
  - **NEW**: Enhanced status badges

- **Progress Tracking**
  - Real-time project progress calculation
  - Task completion tracking
  - Overdue task alerts with critical badges
  - Days remaining calculation
  - **NEW**: Animated progress bars
  - **NEW**: Visual status indicators

- **Reporting & Analytics**
  - Project-wise reports
  - Member-wise performance reports
  - PDF report generation
  - Dashboard with statistics
  - Task status breakdown
  - Team performance metrics
  - **NEW**: Enhanced data visualizations
  - **NEW**: Gradient statistic cards

### UI/UX Features
- **Modern Design System**
  - CSS gradient themes (primary, success, warning, info)
  - Glass morphism card effects
  - Animated gradient backgrounds
  - Floating icon animations
  - Status pulse indicators
  - Custom scrollbar styling
  
- **Enhanced Components**
  - Gradient progress bars with pulse effects
  - 3D badge transforms on hover
  - Icon-prefixed input fields
  - Team member avatars
  - Empty state illustrations
  - Responsive layouts

- **Accessibility**
  - WCAG compliant color contrasts
  - Keyboard navigation support
  - Semantic HTML structure
  - Screen reader friendly
- Message notifications
- Clean and intuitive interface

## Technology Stack

- **Backend:** Python 3.13, Django 5.2
- **Database:** SQLite (default, can be changed to PostgreSQL/MySQL)
- **Frontend:** HTML5, CSS3, Bootstrap 5, Bootstrap Icons
- **PDF Generation:** ReportLab
- **Image Processing:** Pillow

## Installation & Setup

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)

### Step 1: Clone or Download the Project
```bash
cd "Project Management System"
```

### Step 2: Create Virtual Environment (Recommended)
```bash
# On Windows
python -m venv venv
venv\Scripts\activate

# On macOS/Linux
python3 -m venv venv
source venv/bin/activate
```

### Step 3: Install Dependencies
```bash
pip install -r requirements.txt
```

The required packages are:
- Django==5.2.7
- Pillow (for image handling)
- reportlab (for PDF generation)
- python-dateutil (for date handling)

### Step 4: Run Migrations
The database is already migrated, but if you need to reset or make changes:
```bash
python manage.py makemigrations
python manage.py migrate
```

### Step 5: Create Superuser (Admin)
```bash
python manage.py createsuperuser
```

Follow the prompts to create an admin account with username, email, and password.

### Step 6: Run the Development Server
```bash
python manage.py runserver
```

The application will be available at: `http://127.0.0.1:8000/`

## Usage Guide

### Initial Setup

1. **Access the Application**
   - Navigate to `http://127.0.0.1:8000/`
   - You'll see the home page with login and register options

2. **Create Admin Account**
   - Use the superuser account created earlier
   - Login at `http://127.0.0.1:8000/accounts/login/`

3. **Access Admin Panel**
   - Go to `http://127.0.0.1:8000/admin/`
   - Login with superuser credentials
   - Create additional users with different roles

### User Roles & Permissions

#### Admin
- Full access to all features
- Can manage all users, projects, and tasks
- Access to all reports
- Can use Django admin panel

#### Manager
- Create and manage projects
- Assign tasks to team members
- View all reports
- Manage project team members

#### Developer
- View assigned projects and tasks
- Update task status
- Add comments and attachments
- View personal performance reports

#### Tester
- View assigned projects and tasks
- Test and verify tasks
- Update task status
- Add comments and feedback

### Creating Your First Project

1. **Login as Admin or Manager**
2. **Navigate to Projects** → **Create New Project**
3. **Fill in Project Details:**
   - Name
   - Description
   - Status
   - Priority
   - Start and End dates
   - Budget (optional)
   - Manager
   - Team Members
4. **Click "Create"**

### Creating and Assigning Tasks

1. **Navigate to Tasks** → **Create New Task**
2. **Fill in Task Details:**
   - Title
   - Description
   - Project
   - Assigned to (team member)
   - Status
   - Priority
   - Due date
   - Estimated hours
3. **Click "Create"**

### Viewing Reports

1. **Admin/Manager Access:**
   - Navigate to **Reports** in the menu
   - View overall dashboard with statistics

2. **Project Reports:**
   - Click on any project
   - Click "View Report"
   - Download PDF report

3. **Member Reports:**
   - Navigate to Reports → Member Reports
   - Select team member
   - View or download PDF report

### Tracking Progress

1. **Dashboard View:**
   - See overview of all projects and tasks
   - View task status breakdown
   - Check overdue tasks

2. **My Tasks:**
   - Click "My Tasks" to see assigned tasks
   - Filter by status
   - Update task status

## Project Structure

```
Project Management System/
│
├── pms/                          # Main project settings
│   ├── settings.py               # Django settings
│   ├── urls.py                   # Main URL configuration
│   ├── views.py                  # Dashboard views
│   └── wsgi.py                   # WSGI configuration
│
├── accounts/                      # User management app
│   ├── models.py                 # Custom User model
│   ├── views.py                  # Auth views
│   ├── forms.py                  # User forms
│   ├── admin.py                  # Admin configuration
│   └── urls.py                   # URL routing
│
├── projects/                      # Project management app
│   ├── models.py                 # Project, ProjectComment models
│   ├── views.py                  # Project CRUD views
│   ├── forms.py                  # Project forms
│   ├── admin.py                  # Admin configuration
│   └── urls.py                   # URL routing
│
├── tasks/                         # Task management app
│   ├── models.py                 # Task, TaskComment, TaskAttachment models
│   ├── views.py                  # Task CRUD views
│   ├── forms.py                  # Task forms
│   ├── admin.py                  # Admin configuration
│   └── urls.py                   # URL routing
│
├── reports/                       # Reporting app
│   ├── views.py                  # Report generation and PDF views
│   └── urls.py                   # URL routing
│
├── templates/                     # HTML templates
│   ├── base.html                 # Base template
│   ├── home.html                 # Landing page
│   ├── dashboard.html            # Main dashboard
│   ├── accounts/                 # Account templates
│   ├── projects/                 # Project templates (to be created)
│   ├── tasks/                    # Task templates (to be created)
│   └── reports/                  # Report templates (to be created)
│
├── static/                        # Static files
│   └── css/
│       └── custom.css            # Custom styles
│
├── media/                         # User uploaded files
│   ├── profiles/                 # Profile pictures
│   └── task_attachments/         # Task attachments
│
├── db.sqlite3                     # SQLite database
├── manage.py                      # Django management script
├── requirements.txt               # Python dependencies
└── README.md                      # This file
```

## API Endpoints

### Authentication
- `/accounts/register/` - User registration
- `/accounts/login/` - User login
- `/accounts/logout/` - User logout
- `/accounts/profile/` - User profile

### Projects
- `/projects/` - List all projects
- `/projects/create/` - Create new project
- `/projects/<id>/` - Project details
- `/projects/<id>/edit/` - Edit project
- `/projects/<id>/delete/` - Delete project

### Tasks
- `/tasks/` - List all tasks
- `/tasks/my-tasks/` - My assigned tasks
- `/tasks/create/` - Create new task
- `/tasks/<id>/` - Task details
- `/tasks/<id>/edit/` - Edit task
- `/tasks/<id>/delete/` - Delete task

### Reports
- `/reports/` - Reports dashboard
- `/reports/project/<id>/` - Project report
- `/reports/member/<id>/` - Member report
- `/reports/project/<id>/pdf/` - Download project PDF
- `/reports/member/<id>/pdf/` - Download member PDF

## Security Features

- CSRF protection enabled
- Password hashing with Django's built-in system
- Role-based access control
- Login required decorators
- Permission checks on all sensitive operations
- XSS protection
- SQL injection protection (Django ORM)

## Customization

### Changing Database to PostgreSQL

1. Install psycopg2:
```bash
pip install psycopg2-binary
```

2. Update `settings.py`:
```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'pms_db',
        'USER': 'your_username',
        'PASSWORD': 'your_password',
        'HOST': 'localhost',
        'PORT': '5432',
    }
}
```

### Adding Email Notifications

Update `settings.py`:
```python
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = 'your_email@gmail.com'
EMAIL_HOST_PASSWORD = 'your_password'
```

## Troubleshooting

### Issue: Static files not loading
```bash
python manage.py collectstatic
```

### Issue: Database errors
```bash
python manage.py makemigrations
python manage.py migrate
```

### Issue: Permission denied errors
Check user roles and permissions in the admin panel

## Future Enhancements

- [ ] Real-time notifications
- [ ] Email notifications for task assignments
- [ ] Calendar integration
- [ ] Gantt chart visualization
- [ ] Time tracking
- [ ] Sprint planning
- [ ] API endpoints (REST API)
- [ ] Mobile app
- [ ] File version control
- [ ] Advanced analytics

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is created for educational purposes.

## Support

For issues, questions, or suggestions, please create an issue in the project repository.

## Author

Developed as a comprehensive Django project management solution.

## Acknowledgments

- Django Documentation
- Bootstrap 5
- Bootstrap Icons
- ReportLab for PDF generation

---

**Note:** This is a development version. For production use, please:
1. Change `DEBUG = False` in settings.py
2. Set a strong `SECRET_KEY`
3. Configure proper database (PostgreSQL recommended)
4. Set up proper email backend
5. Configure static files serving with WhiteNoise or CDN
6. Enable HTTPS
7. Set up proper backup systems
