from django.urls import path
from . import views

app_name = 'reports'

urlpatterns = [
    path('', views.reports_dashboard, name='dashboard'),
    path('members/', views.member_reports_list, name='member_reports'),
    path('project/<int:pk>/', views.project_report_view, name='project_report'),
    path('member/<int:pk>/', views.member_report_view, name='member_report'),
    path('project/<int:pk>/pdf/', views.generate_project_pdf, name='project_pdf'),
    path('member/<int:pk>/pdf/', views.generate_member_pdf, name='member_pdf'),
]
