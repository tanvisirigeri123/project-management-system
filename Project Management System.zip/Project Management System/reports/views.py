from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import HttpResponse
from django.db.models import Count, Q, Avg
from django.utils import timezone
from datetime import timedelta
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from io import BytesIO

from projects.models import Project
from tasks.models import Task
from accounts.models import User


@login_required
def reports_dashboard(request):
    """Main reports dashboard"""
    if not request.user.can_view_all_reports():
        messages.error(request, 'You do not have permission to view all reports.')
        return render(request, 'reports/limited_access.html')
    
    # Overall statistics
    total_projects = Project.objects.count()
    active_projects = Project.objects.filter(status='in_progress').count()
    completed_projects = Project.objects.filter(status='completed').count()
    total_tasks = Task.objects.count()
    completed_tasks = Task.objects.filter(status='completed').count()
    total_users = User.objects.count()
    
    # Recent projects
    recent_projects = Project.objects.all()[:5]
    
    # Task status breakdown
    task_status_data = Task.objects.values('status').annotate(count=Count('id'))
    
    # Project status breakdown
    project_status_data = Project.objects.values('status').annotate(count=Count('id'))
    
    context = {
        'total_projects': total_projects,
        'active_projects': active_projects,
        'completed_projects': completed_projects,
        'total_tasks': total_tasks,
        'completed_tasks': completed_tasks,
        'total_users': total_users,
        'recent_projects': recent_projects,
        'task_status_data': task_status_data,
        'project_status_data': project_status_data,
    }
    return render(request, 'reports/dashboard.html', context)


@login_required
def member_reports_list(request):
    """List all team members for reports"""
    if not request.user.can_view_all_reports():
        messages.error(request, 'You do not have permission to view member reports.')
        return render(request, 'reports/limited_access.html')
    
    # Get all users with their task statistics
    members = User.objects.annotate(
        total_tasks=Count('assigned_tasks'),
        completed_tasks=Count('assigned_tasks', filter=Q(assigned_tasks__status='completed')),
        in_progress_tasks=Count('assigned_tasks', filter=Q(assigned_tasks__status='in_progress')),
        overdue_tasks=Count('assigned_tasks', 
            filter=Q(
                assigned_tasks__due_date__lt=timezone.now().date(),
                assigned_tasks__status__in=['todo', 'in_progress', 'in_review']
            )
        )
    ).order_by('-total_tasks')
    
    context = {
        'members': members,
    }
    return render(request, 'reports/member_list.html', context)


@login_required
def project_report_view(request, pk):
    """Generate project-wise report"""
    project = get_object_or_404(Project, pk=pk)
    
    # Check access
    if not request.user.can_view_all_reports():
        if (request.user != project.manager and 
            request.user not in project.team_members.all()):
            messages.error(request, 'You do not have permission to view this report.')
            return render(request, 'reports/limited_access.html')
    
    # Calculate project statistics
    tasks = project.tasks.all()
    total_tasks = tasks.count()
    completed_tasks = tasks.filter(status='completed').count()
    in_progress_tasks = tasks.filter(status='in_progress').count()
    overdue_tasks = tasks.filter(
        due_date__lt=timezone.now().date(),
        status__in=['todo', 'in_progress', 'in_review']
    ).count()
    
    # Task breakdown by status
    task_status_breakdown = tasks.values('status').annotate(count=Count('id'))
    
    # Task breakdown by assignee
    task_assignee_breakdown = tasks.values(
        'assigned_to__username', 'assigned_to__first_name', 'assigned_to__last_name'
    ).annotate(
        total=Count('id'),
        completed=Count('id', filter=Q(status='completed'))
    )
    
    context = {
        'project': project,
        'total_tasks': total_tasks,
        'completed_tasks': completed_tasks,
        'in_progress_tasks': in_progress_tasks,
        'overdue_tasks': overdue_tasks,
        'progress': project.get_progress(),
        'task_status_breakdown': task_status_breakdown,
        'task_assignee_breakdown': task_assignee_breakdown,
        'team_members': project.team_members.all(),
    }
    return render(request, 'reports/project_report.html', context)


@login_required
def member_report_view(request, pk):
    """Generate member-wise report"""
    member = get_object_or_404(User, pk=pk)
    
    # Check access
    if not request.user.can_view_all_reports() and request.user != member:
        messages.error(request, 'You do not have permission to view this report.')
        return render(request, 'reports/limited_access.html')
    
    # Get member's projects and tasks
    projects = Project.objects.filter(
        Q(team_members=member) | Q(manager=member)
    ).distinct()
    
    tasks = Task.objects.filter(assigned_to=member)
    total_tasks = tasks.count()
    completed_tasks = tasks.filter(status='completed').count()
    in_progress_tasks = tasks.filter(status='in_progress').count()
    overdue_tasks = tasks.filter(
        due_date__lt=timezone.now().date(),
        status__in=['todo', 'in_progress', 'in_review']
    ).count()
    
    # Task breakdown by status
    task_status_breakdown = tasks.values('status').annotate(count=Count('id'))
    
    # Task breakdown by project
    task_project_breakdown = tasks.values(
        'project__name'
    ).annotate(
        total=Count('id'),
        completed=Count('id', filter=Q(status='completed'))
    )
    
    # Calculate completion rate
    completion_rate = (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0
    
    context = {
        'member': member,
        'projects': projects,
        'total_tasks': total_tasks,
        'completed_tasks': completed_tasks,
        'in_progress_tasks': in_progress_tasks,
        'overdue_tasks': overdue_tasks,
        'completion_rate': round(completion_rate, 2),
        'task_status_breakdown': task_status_breakdown,
        'task_project_breakdown': task_project_breakdown,
        'recent_tasks': tasks[:10],
    }
    return render(request, 'reports/member_report.html', context)


@login_required
def generate_project_pdf(request, pk):
    """Generate PDF report for a project"""
    project = get_object_or_404(Project, pk=pk)
    
    # Check access
    if not request.user.can_view_all_reports():
        if (request.user != project.manager and 
            request.user not in project.team_members.all()):
            messages.error(request, 'You do not have permission to generate this report.')
            return render(request, 'reports/limited_access.html')
    
    # Create PDF
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    elements = []
    
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        textColor=colors.HexColor('#2c3e50'),
        spaceAfter=30,
        alignment=TA_CENTER
    )
    
    # Title
    elements.append(Paragraph(f"Project Report: {project.name}", title_style))
    elements.append(Spacer(1, 0.3*inch))
    
    # Project Information
    project_data = [
        ['Project Name:', project.name],
        ['Manager:', str(project.manager)],
        ['Status:', project.get_status_display()],
        ['Priority:', project.get_priority_display()],
        ['Start Date:', str(project.start_date)],
        ['End Date:', str(project.end_date)],
        ['Progress:', f"{project.get_progress()}%"],
    ]
    
    project_table = Table(project_data, colWidths=[2*inch, 4*inch])
    project_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, -1), colors.grey),
        ('TEXTCOLOR', (0, 0), (0, -1), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
        ('BACKGROUND', (1, 0), (1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    elements.append(project_table)
    elements.append(Spacer(1, 0.3*inch))
    
    # Tasks Summary
    tasks = project.tasks.all()
    elements.append(Paragraph("Tasks Summary", styles['Heading2']))
    elements.append(Spacer(1, 0.2*inch))
    
    task_summary = [
        ['Status', 'Count'],
        ['Total Tasks', tasks.count()],
        ['Completed', tasks.filter(status='completed').count()],
        ['In Progress', tasks.filter(status='in_progress').count()],
        ['To Do', tasks.filter(status='todo').count()],
    ]
    
    task_table = Table(task_summary, colWidths=[3*inch, 2*inch])
    task_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.lightgrey])
    ]))
    elements.append(task_table)
    
    # Build PDF
    doc.build(elements)
    
    # Return PDF response
    buffer.seek(0)
    response = HttpResponse(buffer, content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="project_{project.id}_report.pdf"'
    return response


@login_required
def generate_member_pdf(request, pk):
    """Generate PDF report for a team member"""
    member = get_object_or_404(User, pk=pk)
    
    # Check access
    if not request.user.can_view_all_reports() and request.user != member:
        messages.error(request, 'You do not have permission to generate this report.')
        return render(request, 'reports/limited_access.html')
    
    # Create PDF
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    elements = []
    
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        textColor=colors.HexColor('#2c3e50'),
        spaceAfter=30,
        alignment=TA_CENTER
    )
    
    # Title
    elements.append(Paragraph(f"Member Report: {member.get_full_name() or member.username}", title_style))
    elements.append(Spacer(1, 0.3*inch))
    
    # Member Information
    member_data = [
        ['Name:', member.get_full_name() or member.username],
        ['Username:', member.username],
        ['Email:', member.email],
        ['Role:', member.get_role_display()],
    ]
    
    member_table = Table(member_data, colWidths=[2*inch, 4*inch])
    member_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, -1), colors.grey),
        ('TEXTCOLOR', (0, 0), (0, -1), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
        ('BACKGROUND', (1, 0), (1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    elements.append(member_table)
    elements.append(Spacer(1, 0.3*inch))
    
    # Tasks Summary
    tasks = Task.objects.filter(assigned_to=member)
    elements.append(Paragraph("Tasks Summary", styles['Heading2']))
    elements.append(Spacer(1, 0.2*inch))
    
    task_summary = [
        ['Status', 'Count'],
        ['Total Tasks', tasks.count()],
        ['Completed', tasks.filter(status='completed').count()],
        ['In Progress', tasks.filter(status='in_progress').count()],
        ['To Do', tasks.filter(status='todo').count()],
    ]
    
    task_table = Table(task_summary, colWidths=[3*inch, 2*inch])
    task_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.lightgrey])
    ]))
    elements.append(task_table)
    
    # Build PDF
    doc.build(elements)
    
    # Return PDF response
    buffer.seek(0)
    response = HttpResponse(buffer, content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="member_{member.id}_report.pdf"'
    return response
