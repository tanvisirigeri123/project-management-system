"""
Script to create sample data for testing the Project Management System.
Run this after creating a superuser:
    python manage.py shell < create_sample_data.py
"""

from accounts.models import User
from projects.models import Project
from tasks.models import Task
from datetime import datetime, timedelta

print("Creating sample users...")

# Create users with different roles if they don't exist
users_data = [
    {'username': 'john_manager', 'email': 'john@example.com', 'first_name': 'John', 'last_name': 'Manager', 'role': 'manager', 'password': 'test1234'},
    {'username': 'alice_dev', 'email': 'alice@example.com', 'first_name': 'Alice', 'last_name': 'Developer', 'role': 'developer', 'password': 'test1234'},
    {'username': 'bob_dev', 'email': 'bob@example.com', 'first_name': 'Bob', 'last_name': 'Developer', 'role': 'developer', 'password': 'test1234'},
    {'username': 'charlie_tester', 'email': 'charlie@example.com', 'first_name': 'Charlie', 'last_name': 'Tester', 'role': 'tester', 'password': 'test1234'},
]

created_users = []
for user_data in users_data:
    user, created = User.objects.get_or_create(
        username=user_data['username'],
        defaults={
            'email': user_data['email'],
            'first_name': user_data['first_name'],
            'last_name': user_data['last_name'],
            'role': user_data['role'],
        }
    )
    if created:
        user.set_password(user_data['password'])
        user.save()
        print(f"✓ Created user: {user.username}")
    else:
        print(f"- User already exists: {user.username}")
    created_users.append(user)

manager = User.objects.get(username='john_manager')
alice = User.objects.get(username='alice_dev')
bob = User.objects.get(username='bob_dev')
charlie = User.objects.get(username='charlie_tester')

print("\nCreating sample projects...")

# Create sample projects
projects_data = [
    {
        'name': 'E-Commerce Website',
        'description': 'Build a modern e-commerce platform with shopping cart, payment integration, and admin dashboard.',
        'status': 'in_progress',
        'priority': 'high',
        'manager': manager,
        'team_members': [alice, bob, charlie],
    },
    {
        'name': 'Mobile App Development',
        'description': 'Develop a cross-platform mobile application for iOS and Android.',
        'status': 'planning',
        'priority': 'medium',
        'manager': manager,
        'team_members': [alice, bob],
    },
    {
        'name': 'Database Migration',
        'description': 'Migrate legacy database to new cloud-based solution.',
        'status': 'completed',
        'priority': 'critical',
        'manager': manager,
        'team_members': [bob, charlie],
    },
]

created_projects = []
for i, proj_data in enumerate(projects_data):
    start_date = datetime.now().date() - timedelta(days=30-i*10)
    end_date = start_date + timedelta(days=90)
    
    project, created = Project.objects.get_or_create(
        name=proj_data['name'],
        defaults={
            'description': proj_data['description'],
            'status': proj_data['status'],
            'priority': proj_data['priority'],
            'start_date': start_date,
            'end_date': end_date,
            'budget': 50000 + i*10000,
            'manager': proj_data['manager'],
            'created_by': proj_data['manager'],
        }
    )
    if created:
        project.team_members.set(proj_data['team_members'])
        print(f"✓ Created project: {project.name}")
    else:
        print(f"- Project already exists: {project.name}")
    created_projects.append(project)

print("\nCreating sample tasks...")

# Create sample tasks
tasks_data = [
    # E-Commerce tasks
    {'title': 'Design homepage layout', 'project': 0, 'assigned_to': alice, 'status': 'completed', 'priority': 'high'},
    {'title': 'Implement shopping cart', 'project': 0, 'assigned_to': alice, 'status': 'in_progress', 'priority': 'high'},
    {'title': 'Integrate payment gateway', 'project': 0, 'assigned_to': bob, 'status': 'todo', 'priority': 'critical'},
    {'title': 'Test checkout process', 'project': 0, 'assigned_to': charlie, 'status': 'in_review', 'priority': 'high'},
    
    # Mobile App tasks
    {'title': 'Setup React Native environment', 'project': 1, 'assigned_to': alice, 'status': 'completed', 'priority': 'medium'},
    {'title': 'Design app screens', 'project': 1, 'assigned_to': alice, 'status': 'in_progress', 'priority': 'medium'},
    {'title': 'Implement authentication', 'project': 1, 'assigned_to': bob, 'status': 'todo', 'priority': 'high'},
    
    # Database Migration tasks
    {'title': 'Backup existing database', 'project': 2, 'assigned_to': bob, 'status': 'completed', 'priority': 'critical'},
    {'title': 'Setup cloud database', 'project': 2, 'assigned_to': bob, 'status': 'completed', 'priority': 'critical'},
    {'title': 'Verify data integrity', 'project': 2, 'assigned_to': charlie, 'status': 'completed', 'priority': 'high'},
]

for i, task_data in enumerate(tasks_data):
    project = created_projects[task_data['project']]
    due_date = datetime.now().date() + timedelta(days=7+i*3)
    
    task, created = Task.objects.get_or_create(
        title=task_data['title'],
        project=project,
        defaults={
            'description': f"Detailed description for: {task_data['title']}",
            'assigned_to': task_data['assigned_to'],
            'status': task_data['status'],
            'priority': task_data['priority'],
            'due_date': due_date,
            'estimated_hours': 8 + i,
            'actual_hours': 6 + i if task_data['status'] == 'completed' else None,
            'created_by': manager,
        }
    )
    if created:
        print(f"✓ Created task: {task.title}")
    else:
        print(f"- Task already exists: {task.title}")

print("\n" + "="*50)
print("Sample data created successfully!")
print("="*50)
print("\nTest Credentials:")
print("-"*50)
print("Manager: john_manager / test1234")
print("Developer: alice_dev / test1234")
print("Developer: bob_dev / test1234")
print("Tester: charlie_tester / test1234")
print("-"*50)
print("\nYou can now login and test the system!")
