from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    """Custom User model with role-based access"""
    
    ROLE_CHOICES = [
        ('admin', 'Admin'),
        ('manager', 'Manager'),
        ('developer', 'Developer'),
        ('tester', 'Tester'),
    ]
    
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='developer')
    phone = models.CharField(max_length=15, blank=True, null=True)
    profile_picture = models.ImageField(upload_to='profiles/', blank=True, null=True)
    bio = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.username} ({self.get_role_display()})"
    
    def is_admin(self):
        return self.role == 'admin'
    
    def is_manager(self):
        return self.role == 'manager'
    
    def is_developer(self):
        return self.role == 'developer'
    
    def is_tester(self):
        return self.role == 'tester'
    
    def can_manage_projects(self):
        """Check if user can create/edit projects"""
        return self.role in ['admin', 'manager']
    
    def can_assign_tasks(self):
        """Check if user can assign tasks"""
        return self.role in ['admin', 'manager']
    
    def can_view_all_reports(self):
        """Check if user can view all reports"""
        return self.role in ['admin', 'manager']
    
    class Meta:
        ordering = ['username']
